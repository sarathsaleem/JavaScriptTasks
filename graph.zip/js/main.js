/*jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4, maxerr: 50 */
/*global require, define, brackets: true, $, PathUtils, window, navigator, Mustache */

require.config({
    baseUrl: 'js',
    urlArgs: "bust=" + (new Date()).getTime(), //prevent cache for testing 
    paths: {
        knockout    : 'libs/knockout',
        d3          : 'libs/d3',
        stackdata   : 'data/stackdata',        
        stackgraph   : 'graph/stackgraph'

    }, 
    shim: {
        d3: {
            exports: 'd3'
        }
    }
});

define(function (require, exports, module) {
    "use strict";

    //load libs
    var ko = require('knockout'),
        d3 = require('d3'),
        stackData = require('stackdata'),
        stackGraph = require('stackgraph');

    function GraphOverflow() {
        stackData.call(this);
        this.getTags();

        this.popularLanguages.subscribe(function (val) {
            stackGraph.drawBubleChart($('.popular-languages .graph')[0], val);
        });
               
        this.languageCount.subscribe(function (val) {
            //stackGraph.drawBubleChart($('.language-count .graph')[0], val);
        });
    }

    $(function () {
        ko.applyBindings(new GraphOverflow(), $('html')[0]);
    });

});