var custom_bubble_chart = (function (d3, CustomTooltip) {
    "use strict";

    var width = 940,
        height = 600,
        tooltip = CustomTooltip("gates_tooltip", 240),
        layout_gravity = -0.01,
        damper = 0.1,
        nodes = [],
        vis, force, circles, radius_scale;

    var center = {
        x: width / 2,
        y: height / 2
    };

    var year_centers = {
        "2008": {
            x: width / 3,
            y: height / 2
        },
        "2009": {
            x: width / 2,
            y: height / 2
        },
        "2010": {
            x: 2 * width / 3,
            y: height / 2
        }
    };

    var fill_color = d3.scale.ordinal()
        .domain(["low", "medium", "high"])
        .range(["#d84b2a", "#beccae", "#7aa25c"]);

    function custom_chart(data) {
        var max_amount = d3.max(data, function (d) {
            return parseInt(d.total_amount, 10);
        });
        radius_scale = d3.scale.pow().exponent(0.5).domain([0, max_amount]).range([2, 85]);

        //create node objects from original data
        //that will serve as the data behind each
        //bubble in the vis, then add each node
        //to nodes to be used later
        data.forEach(function (d) {
            var node = {
                id: d.id,
                radius: radius_scale(parseInt(d.total_amount, 10)),
                value: d.total_amount,
                name: d.grant_title,
                org: d.organization,
                group: d.group,
                year: d.start_year,
                x: Math.random() * 900,
                y: Math.random() * 800
            };
            nodes.push(node);
        });

        nodes.sort(function (a, b) {
            return b.value - a.value;
        });

        vis = d3.select("#vis").append("svg")
            .attr("width", width)
            .attr("height", height)
            .attr("id", "svg_vis");

        circles = vis.selectAll("circle")
            .data(nodes, function (d) {
            return d.id;
        });

        circles.enter().append("circle")
            .attr("r", 0)
            .attr("fill", function (d) {
            return fill_color(d.group);
        })
            .attr("stroke-width", 2)
            .attr("stroke", function (d) {
            return d3.rgb(fill_color(d.group)).darker();
        })
            .attr("id", function (d) {
            return "bubble_" + d.id;
        })
            .on("mouseover", function (d, i) {
            show_details(d, i, this);
        })
            .on("mouseout", function (d, i) {
            hide_details(d, i, this);
        });

        circles.transition().duration(2000).attr("r", function (d) {
            return d.radius;
        });

    }

    function charge(d) {
        return -Math.pow(d.radius, 2.0) / 8;
    }

    function start() {
        force = d3.layout.force()
            .nodes(nodes)
            .size([width, height]);
    }

    function display_group_all() {
        force.gravity(layout_gravity)
            .charge(charge)
            .friction(0.9)
            .on("tick", function (e) {
            circles.each(move_towards_center(e.alpha))
                .attr("cx", function (d) {
                return d.x;
            })
                .attr("cy", function (d) {
                return d.y;
            });
        });
        force.start();
        hide_years();
    }

    function move_towards_center(alpha) {
        return function (d) {
            d.x = d.x + (center.x - d.x) * (damper + 0.02) * alpha;
            d.y = d.y + (center.y - d.y) * (damper + 0.02) * alpha;
        };
    }

    function display_by_year() {
        force.gravity(layout_gravity)
            .charge(charge)
            .friction(0.9)
            .on("tick", function (e) {
            circles.each(move_towards_year(e.alpha))
                .attr("cx", function (d) {
                return d.x;
            })
                .attr("cy", function (d) {
                return d.y;
            });
        });
        force.start();
        display_years();
    }

    function move_towards_year(alpha) {
        return function (d) {
            var target = year_centers[d.year];
            d.x = d.x + (target.x - d.x) * (damper + 0.02) * alpha * 1.1;
            d.y = d.y + (target.y - d.y) * (damper + 0.02) * alpha * 1.1;
        };
    }


    function display_years() {
        var years_x = {
            "2008": 160,
            "2009": width / 2,
            "2010": width - 160
        };
        var years_data = d3.keys(years_x);
        var years = vis.selectAll(".years")
            .data(years_data);

        years.enter().append("text")
            .attr("class", "years")
            .attr("x", function (d) {
            return years_x[d];
        })
            .attr("y", 40)
            .attr("text-anchor", "middle")
            .text(function (d) {
            return d;
        });

    }

    function hide_years() {
        var years = vis.selectAll(".years").remove();
    }


    function show_details(data, i, element) {
        d3.select(element).attr("stroke", "black");
        var content = "<span class=\"name\">Title:</span><span class=\"value\"> " + data.name + "</span><br/>";
        content += "<span class=\"name\">Amount:</span><span class=\"value\"> $" + addCommas(data.value) + "</span><br/>";
        content += "<span class=\"name\">Year:</span><span class=\"value\"> " + data.year + "</span>";
        tooltip.showTooltip(content, d3.event);
    }

    function hide_details(data, i, element) {
        d3.select(element).attr("stroke", function (d) {
            return d3.rgb(fill_color(d.group)).darker();
        });
        tooltip.hideTooltip();
    }

    var my_mod = {};
    my_mod.init = function (_data) {
        custom_chart(_data);
        start();
    };

    my_mod.display_all = display_group_all;
    my_mod.display_year = display_by_year;
    my_mod.toggle_view = function (view_type) {
        if (view_type == 'year') {
            display_by_year();
        } else {
            display_group_all();
        }
    };

    return my_mod;
})(d3, CustomTooltip);
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//---------------------------------------------https://github.com/mbostock/bost.ocks.org/blob/gh-pages/mike/nations/index.html-------------------------------------------------------------
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Various accessors that specify the four dimensions of data to visualize.

function x(d) {
    return d.income;
}

function y(d) {
    return d.lifeExpectancy;
}

function radius(d) {
    return d.population;
}

function color(d) {
    return d.region;
}

function key(d) {
    return d.name;
}

// Chart dimensions.
var margin = {
    top: 19.5,
    right: 19.5,
    bottom: 19.5,
    left: 39.5
},
    width = 960 - margin.right,
    height = 500 - margin.top - margin.bottom;

// Various scales. These domains make assumptions of data, naturally.
var xScale = d3.scale.log().domain([300, 1e5]).range([0, width]),
    yScale = d3.scale.linear().domain([10, 85]).range([height, 0]),
    radiusScale = d3.scale.sqrt().domain([0, 5e8]).range([0, 40]),
    colorScale = d3.scale.category10();

// The x & y axes.
var xAxis = d3.svg.axis().orient("bottom").scale(xScale).ticks(12, d3.format(",d")),
    yAxis = d3.svg.axis().scale(yScale).orient("left");

// Create the SVG container and set the origin.
var svg = d3.select("#chart").append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

// Add the x-axis.
svg.append("g")
    .attr("class", "x axis")
    .attr("transform", "translate(0," + height + ")")
    .call(xAxis);

// Add the y-axis.
svg.append("g")
    .attr("class", "y axis")
    .call(yAxis);

// Add an x-axis label.
svg.append("text")
    .attr("class", "x label")
    .attr("text-anchor", "end")
    .attr("x", width)
    .attr("y", height - 6)
    .text("income per capita, inflation-adjusted (dollars)");

// Add a y-axis label.
svg.append("text")
    .attr("class", "y label")
    .attr("text-anchor", "end")
    .attr("y", 6)
    .attr("dy", ".75em")
    .attr("transform", "rotate(-90)")
    .text("life expectancy (years)");

// Add the year label; the value is set on transition.
var label = svg.append("text")
    .attr("class", "year label")
    .attr("text-anchor", "end")
    .attr("y", height - 24)
    .attr("x", width)
    .text(1800);

// Load the data.
d3.json("nations.json", function (nations) {

    // A bisector since many nation's data is sparsely-defined.
    var bisect = d3.bisector(function (d) {
        return d[0];
    });

    // Add a dot per nation. Initialize the data at 1800, and set the colors.
    var dot = svg.append("g")
        .attr("class", "dots")
        .selectAll(".dot")
        .data(interpolateData(1800))
        .enter().append("circle")
        .attr("class", "dot")
        .style("fill", function (d) {
        return colorScale(color(d));
    })
        .call(position)
        .sort(order);

    // Add a title.
    dot.append("title")
        .text(function (d) {
        return d.name;
    });

    // Add an overlay for the year label.
    var box = label.node().getBBox();

    var overlay = svg.append("rect")
        .attr("class", "overlay")
        .attr("x", box.x)
        .attr("y", box.y)
        .attr("width", box.width)
        .attr("height", box.height)
        .on("mouseover", enableInteraction);

    // Start a transition that interpolates the data based on year.
    svg.transition()
        .duration(30000)
        .ease("linear")
        .tween("year", tweenYear)
        .each("end", enableInteraction);

    // Positions the dots based on data.

    function position(dot) {
        dot.attr("cx", function (d) {
            return xScale(x(d));
        })
            .attr("cy", function (d) {
            return yScale(y(d));
        })
            .attr("r", function (d) {
            return radiusScale(radius(d));
        });
    }

    // Defines a sort order so that the smallest dots are drawn on top.

    function order(a, b) {
        return radius(b) - radius(a);
    }

    // After the transition finishes, you can mouseover to change the year.

    function enableInteraction() {
        var yearScale = d3.scale.linear()
            .domain([1800, 2009])
            .range([box.x + 10, box.x + box.width - 10])
            .clamp(true);

        // Cancel the current transition, if any.
        svg.transition().duration(0);

        overlay
            .on("mouseover", mouseover)
            .on("mouseout", mouseout)
            .on("mousemove", mousemove)
            .on("touchmove", mousemove);

        function mouseover() {
            label.classed("active", true);
        }

        function mouseout() {
            label.classed("active", false);
        }

        function mousemove() {
            displayYear(yearScale.invert(d3.mouse(this)[0]));
        }
    }

    // Tweens the entire chart by first tweening the year, and then the data.
    // For the interpolated data, the dots and label are redrawn.

    function tweenYear() {
        var year = d3.interpolateNumber(1800, 2009);
        return function (t) {
            displayYear(year(t));
        };
    }

    // Updates the display to show the specified year.

    function displayYear(year) {
        dot.data(interpolateData(year), key).call(position).sort(order);
        label.text(Math.round(year));
    }

    // Interpolates the dataset for the given (fractional) year.

    function interpolateData(year) {
        return nations.map(function (d) {
            return {
                name: d.name,
                region: d.region,
                income: interpolateValues(d.income, year),
                population: interpolateValues(d.population, year),
                lifeExpectancy: interpolateValues(d.lifeExpectancy, year)
            };
        });
    }

    // Finds (and possibly interpolates) the value for the specified year.

    function interpolateValues(values, year) {
        var i = bisect.left(values, year, 0, values.length - 1),
            a = values[i];
        if (i > 0) {
            var b = values[i - 1],
                t = (year - a[0]) / (b[0] - a[0]);
            return a[1] * (1 - t) + b[1] * t;
        }
        return a[1];
    }
});