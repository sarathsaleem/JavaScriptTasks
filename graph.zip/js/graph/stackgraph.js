/*jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4, maxerr: 50 */
/*global require, define, brackets: true, $, window, navigator */
/*
 * 1. Get list of tags by largest number of questions asked
 *   - from bigning.
 *   - this year.
 *   - this month.
 *   - this week.
 *   - today
 *
 * 2. Get number of questions asked aganist first 25 tags
 *   - from bigning.
 *   - this year.
 *   - this month.
 *   - this week.
 *   - today
 *
 * 3. Get the top 10 related tags asked aganist first 25 tags
 *   - from bigning.
 *   - this year.
 *   - this month.
 *   - this week.
 *   - today
 *
 */
define(function (require) {

    "use strict";

    var d3 = require('d3');

    var stackGraph = function () {

        this.drawBubleChart = function (container, data) {

            $(container).html('');
            var width = $(container).width(),
                height = $(container).height(),
                nodes = [],
                chart,
                circles,
                force,
                layout_gravity = -0.01,
                damper = 0.1,
                radius_scale,
                color = d3.scale.category20c();
            var max_count = d3.max(data, function (d) {
                return parseInt(d.count, 10);
            });

            var center = {
                x: width / 2,
                y: height / 2
            };
            var sort = function (a, b) {
                return b.value - a.value;
            };

            radius_scale = d3.scale.pow().exponent(0.5).domain([0, max_count]).range([2, 85]);

            chart = d3.select(container).append("svg")
                .attr("width", width)
                .attr("height", height);

            data.forEach(function (d) {
                var node = {
                    id: d.name,
                    radius: radius_scale(parseInt(d.count, 10)),
                    value: d.count,
                    name: d.name,
                    x: 0,
                    y: 0
                };
                nodes.push(node);
            });

            function draw() {

                nodes.sort(sort);

                circles = chart.selectAll(".node").data(nodes);
                console.log(circles);

                circles.enter().append("g")
                    .attr("class", "node").attr("transform", sort_buble)
                    .append("circle")
                    .attr("r", 0)
                    .attr("fill", function (d, i) {
                    return color(i);
                })
                    .attr("id", function (d) {
                    return "bubble_" + d.id;
                });

                circles.append("text")
                    .attr("dy", ".3em").style("color", '#fff')
                    .style("text-anchor", "middle").text(function (d) {
                    return d.name;
                });

                circles.select('circle').transition().duration(1000).attr("r", function (d) {
                    return d.radius;
                })

            }

            function start() {
                force = d3.layout.force()
                    .nodes(nodes)
                    .size([width, height]);
            }

            function charge(d) {
                return -Math.pow(d.radius, 2.0) / 8;
            }

            function display() {
                force.gravity(layout_gravity)
                    .charge(charge)
                    .friction(0.9)
                    .on("tick", function (e) {
                    circles.each(sort_buble(e.alpha))
                        .attr("transform", function (d) {
                        return "translate(" + d.x + "," + d.y + ")";
                    });
                });
                force.start();
            }

            function move_towards_center(alpha) {
                return function (d) {
                    d.x = d.x + (center.x - d.x) * (damper + 0.02) * alpha;
                    d.y = d.y + (center.y - d.y) * (damper + 0.02) * alpha;
                };
            }

            var row = 1,
                prevR = 0,
                prevDx = 0,
                prevRh = 0,
                rH = 0;

            function sort_buble(d) {
                
                var dx = prevDx + prevR + d.radius;
                if (dx > width) {
                    row++;
                    prevR = 0;
                    prevDx = 0;
                    prevRh = d.radius;
                    dx = prevDx + prevR + d.radius;
                    rH += prevRh;
                }
                
                var dy = rH + d.radius;

                prevR = d.radius;
                prevDx = dx;
                return "translate(" + dx + "," + dy + ")";

            }

            draw();
            start();
            //display();
        };


    };

    return new stackGraph();
});