/*jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4, maxerr: 50 */
/*global require, define, brackets: true, $, window, navigator */
/*
 * 1. Get list of tags by largest number of questions asked
 *   - from bigning.
 *   - this year.
 *   - this month.
 *   - this week.
 *   - today
 *
 * 2. Get number of questions asked aganist first 25 tags
 *   - from bigning.
 *   - this year.
 *   - this month.
 *   - this week.
 *   - today
 *
 * 3. Get the top 10 related tags asked aganist first 25 tags
 *   - from bigning.
 *   - this year.
 *   - this month.
 *   - this week.
 *   - today
 *
 */
define(function (require) {

    "use strict";

    var ko = require('knockout');


    var baseUrl = "http://api.stackexchange.com/2.1/",
        key = "key=U4DMV*8nvpm3EOpvf69Rxw((&site=stackoverflow";

    var _u = (function () {

        function getDateFormat(o) {
            var dateTime = new Date();
            dateTime.setUTCHours(0);
            dateTime.setUTCMinutes(0);
            dateTime.setUTCSeconds(0);
            if (o.day) {
                dateTime.setUTCDate(dateTime.getUTCDate() - o.day);
            }
            if (o.m) {
                dateTime.setUTCMonth(dateTime.getUTCDate() - o.m);
            }
            if (o.y) {
                dateTime.setUTCFullYear(dateTime.getUTCFullYear() - o.y);
            }
            return Math.round(dateTime.getTime() / 1000);
        }

        return {
            getData: function (options, callback, scope) {
                var ajaxParams = $.extend({
                    url: baseUrl,
                    async: false,
                    contentType: "application/json",
                    dataType: 'jsonp',
                    success: function (json) {
                        scope = scope || window;
                        callback.apply(scope, [json]);
                    },
                    error: function (e) {
                        console.log(e.message);
                    }
                }, options);

                $.ajax(ajaxParams);

            },
            getDateInFormat: function (yy, mm, dd) {
                return getDateFormat(yy, mm, dd);
            },
            today: function (day) {
                day = day || 0;
                return getDateFormat({
                    day: day
                });
            },
            month: function (m) {
                m = m || 0;
                return getDateFormat({
                    m: m
                });
            },
            year: function (y) {
                y = y || 0;
                return getDateFormat({
                    y: y
                });
            }

        };

    }());

    var methods = {
        getCountOfTagQuestions: function (tag, frm, to, cb) {
            _u.getData({
                url: baseUrl + 'search?' + key + '&fromdate=' + frm + '&todate=' + to + '&order=desc&sort=activity&tagged=' + encodeURIComponent(tag) + '&filter=!4.N084CshSY9)BTkI',
                method: 'get',
                data: ""
            }, cb, this);

        },
        getTags: function (cb) {
            _u.getData({
                url: baseUrl + 'tags?' + key + '&order=desc&sort=popular&filter=default&pagesize=30',
                method: 'get',
                data: ""
            }, cb, this);
        },
        getTagsRelatedTags: function (tag, cb) {
            _u.getData({
                url: baseUrl + 'tags/' + tag + '/related?' + key + '&order=desc&sort=activity&pagesize=100',
                method: 'get',
                data: ""
            }, cb, this);
        }
    };


    var stackOverFlowModel = function () {

        var that = this;

        this.popularLanguages = ko.observableArray();
        this.languageCount = ko.observableArray();
        this.tags_javascript = ko.observableArray();

        this.lanCountSorted = ko.computed(function () {
            return that.languageCount().sort(function (a, b) {
                return b.count - a.count;
            });
        });

        this.getTags = function () {
            methods.getTags(function (data) {
                that.popularLanguages(data.items);
                that.popularLanguages().forEach(function (lan) {
                    that.getCountOfTagQuestions(lan.name, 1);

                });
            });
        };
        this.getCountOfTagQuestions = function (language, day) {
            methods.getCountOfTagQuestions(language, _u.today(day), _u.today(), function (data) {
                that.languageCount.push({
                    name: language,
                    count: data.total
                });
            });
        };

        this.getTagsRelatedTags = function (tag) {
            methods.getTagsRelatedTags(tag, function (data) {
                that.tags_javascript(data.items);
            });
        };

    };

    return stackOverFlowModel;

});